## Javascript Environment

We have an direct dependencies from nodejs and npm, they can be installed separately or both with [nvm](https://github.com/creationix/nvm)

### dependencies:

* nodejs
* npm
* karma - Make the communication with karma and jenkins. See more on [karma](http://karma-runner.github.io/0.13/index.html)
* mocha - Unit test tool. See more on [http://mochajs.org](http://mochajs.org/)
* jspm - Don't need compile the code, it use babel (or traucer or typescript) to run ES6 code on browser. Know more in [jspm.io](http://jspm.io/)

### how to set up this directory and make it ready for starting work;

Inside this template folder you need to do ```npm run init-setup``` and a basic structure is created;
